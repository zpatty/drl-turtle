import cv2
import numpy as np
import time
import sys
sys.path.append("pytorchYOLOv4")
from tool import darknet2pytorch
import torch
import torchvision.transforms as transforms
# load weights from darknet format
from tool.utils import *
from tool.torch_utils import *
from tool.darknet2pytorch import Darknet
import torch
import argparse

net = darknet2pytorch.Darknet('turtle.cfg', inference=True)
net.load_weights('turtle_7000.weights')

# save weights to pytorch format
torch.save(net.state_dict(), 'turtle_7000.pth')

# reload weights from pytorch format
net = darknet2pytorch.Darknet('turtle.cfg', inference=True)
net.load_state_dict(torch.load('turtle_7000.pth'))

# Load YOLO model with pre-trained weights
model = cv2.dnn.readNet("turtle.cfg", "turtle_7000.weights")

#net.setPreferableBackend(cv2.dnn.DNN_BACKEND_CUDA)
#net.setPreferableTarget(cv2.dnn.DNN_TARGET_CUDA_FP16)
# Load COCO labels for Tiny YOLO

with open("turtle.names", "r") as f:
    classes = f.read().strip().split("\n")

# Get output layer names (specific to YOLO Tiny)
output_layers = model.getUnconnectedOutLayersNames()
print(output_layers)

# Function to perform object detection on an image
def detect_objects(image):
    
    sized = cv2.resize(image, (416, 416)) 
    sized = cv2.cvtColor(sized, cv2.COLOR_BGR2RGB) 
    net.cuda()
    #for i in range(2): 
    start = time.time() 
    boxes = do_detect(net, sized, 0.4, 0.6, True) 
    finish = time.time() 
         
  
    image = plot_boxes_cv2(image, boxes[0], savename=None, class_names=classes) 


    return image



# Function to play video and perform object detection in real-time
def play_video_with_detection(video_path = "camera"):

    # Detect from camera instead of video
    if video_path == "camera":
        video_path = 0
        print(video_path)

    cap = cv2.VideoCapture(video_path)

    frame_count = 0
    total_time = 0

    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break

        # Perform object detection on the frame
        start_time = time.time()
        frame = detect_objects(frame)
        end_time = time.time()

        # Calculate the time taken for detection in the current frame
        elapsed_time = end_time - start_time
        total_time += elapsed_time
        frame_count += 1
        print(frame_count/total_time)
        # Display the frame
        cv2.imshow("Object Detection", frame)

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()

    # Calculate the average time taken per frame
    avg_time_per_frame = total_time / frame_count
    frames_per_second = 1/avg_time_per_frame
    print("Average fps:", frames_per_second)

if __name__ == "__main__":
    video_path = "live_stream_test_short.mov"  # Replace with your video file path
    play_video_with_detection(video_path)
