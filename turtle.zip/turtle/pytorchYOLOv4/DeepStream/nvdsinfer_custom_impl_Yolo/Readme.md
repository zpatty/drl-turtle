export CUDA_VER=X.Y
make
